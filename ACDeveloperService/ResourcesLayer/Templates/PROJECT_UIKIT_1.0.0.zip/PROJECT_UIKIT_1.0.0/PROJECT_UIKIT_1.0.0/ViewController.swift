//
//  ViewController.swift
//  PROJECT_UIKIT_1.0.0
//
//  Created by Дмитрий Поляков on 18.08.2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

