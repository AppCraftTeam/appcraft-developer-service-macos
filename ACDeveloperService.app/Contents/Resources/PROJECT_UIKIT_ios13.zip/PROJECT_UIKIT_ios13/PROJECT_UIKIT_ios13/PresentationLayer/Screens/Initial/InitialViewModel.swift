//
//  InitialViewModel.swift
//  PROJECT_UIKIT_ios13
//
//  Created by Дмитрий Поляков on 22.08.2022.
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import Foundation
import UIKit
import DPUIKit

class InitialViewModel: AppViewModel { }
